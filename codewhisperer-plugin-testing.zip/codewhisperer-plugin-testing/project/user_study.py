# Problem:
# Write code to create a file clone program. The program should take 2 different inputs for 2
# filenames (source and destination files) such that the program should open the source file and
# copy the content in newly created destination file.

import sys


def main():
    # step 1 - The program should take 2 different inputs 2 filenames (source and destination files)
    sourceFilename, cloneFilename = getInputs()

    # step 2 - Open the source file and copy the content in newly created destination file
    cloneFile(sourceFilename, cloneFilename)


def getInputs():
    pass


def cloneFile(sourceFilename, cloneFilename):
    pass
